from llama_ez_distill import LlamaPort

port = LlamaPort("model/stable-diffusion-coreml.mlpackage")

ethics = port.simulate_ethics_cycle({"morality": 0.68})
print("Ethics Snapshot:", ethics)

boss = port.generate_boss_challenge(8)
print("Boss Encounter:", boss)

with open("examples/test_world_state.json", "r") as f:
    world_model = json.load(f)
threats = port.get_threat_snapshot(world_model)
print("Threat Snapshot:", threats)

port.generate_visual("rogue_boss", boss, style="vapor_morality_matrix")
