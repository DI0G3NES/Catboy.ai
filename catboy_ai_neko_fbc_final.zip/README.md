# catboy.ai — neko.fbc Fork

This is the mobile-first recursive AI + compression IDE fork of Diogenes_Mobile.

## Features:
- Custom `.fbc` image compression format
- Recursive visual encoding with moral entropy tags
- Supports both encoding and decoding
- Preparing for DURST (Rust/COBOL hybrid) code execution

## Modules:
- `firebar_compression.py` — Core image compressor
- `neko_distill_core.py` — (To be written) IDE + ethical interface

Stay tuned. Meow.