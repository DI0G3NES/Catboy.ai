"""
Firebar Compression Engine (encode + decode) with DURST payload embedding
Format: .fbc — Fire-aware Binary Compression with moral entropy metadata and optional DURST code capsule
"""

import json
import numpy as np
from PIL import Image

class FirebarCompressor:
    def __init__(self):
        self.version = "NekoEntropy v1"

    def encode(self, image_path, metadata, output_path, durst_code=None):
        image = Image.open(image_path).convert("RGB")
        pixels = np.array(image)
        h, w, _ = pixels.shape
        flat = pixels.reshape(-1, 3)

        # RLE-like encoding (simple bytewise run compression)
        compressed = []
        last_pixel = None
        count = 0
        for px in flat:
            px_tuple = tuple(px)
            if px_tuple == last_pixel:
                count += 1
            else:
                if last_pixel is not None:
                    compressed.append((last_pixel, count))
                last_pixel = px_tuple
                count = 1
        compressed.append((last_pixel, count))

        # Prepare metadata block
        header = {
            "version": self.version,
            "dimensions": [h, w],
            "metadata": metadata,
            "durst_embedded": durst_code is not None
        }

        with open(output_path, "wb") as f:
            f.write(json.dumps(header).encode("utf-8"))
            f.write(b"::FBC::")
            for color, count in compressed:
                f.write(bytes(color))
                f.write(count.to_bytes(2, "big"))
            if durst_code:
                f.write(b"::DURST::")
                f.write(durst_code.encode("utf-8"))
        return output_path

    def decode(self, fbc_path):
        with open(fbc_path, "rb") as f:
            content = f.read()
        segments = content.split(b"::FBC::", 1)
        header_raw = segments[0]
        rest = segments[1]
        header = json.loads(header_raw.decode("utf-8"))
        h, w = header["dimensions"]

        if b"::DURST::" in rest:
            pixel_data, durst_code = rest.split(b"::DURST::", 1)
            durst = durst_code.decode("utf-8")
        else:
            pixel_data = rest
            durst = None

        pixels = []
        i = 0
        while i < len(pixel_data):
            r, g, b = pixel_data[i], pixel_data[i+1], pixel_data[i+2]
            count = int.from_bytes(pixel_data[i+3:i+5], "big")
            pixels.extend([(r, g, b)] * count)
            i += 5

        image_array = np.array(pixels, dtype=np.uint8).reshape((h * w, 3)).reshape((h, w, 3))
        image = Image.fromarray(image_array)
        return image, header, durst
