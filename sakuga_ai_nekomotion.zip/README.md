# sakuga.ai — NekoMotion Engine

This is the visual stylization engine for `catboy.ai`, using Ai-tan-generated frames and rendering them in **2D Sakuga-inspired motion**.

## Influences:
- **Fortiche**: Lighting-based camera motion and strong keyframe holds
- **Wit Studio**: Staggered timing + expressive silhouettes
- **Mushoku Tensei**: Subtle power motion arcs
- **Frieren**: Minimalist transitions + stillness weight
- **Ping Pong**: Shape-based expression & visual exaggeration

## Usage:
```python
from neko_motion import NekoMotionEngine

motion = NekoMotionEngine("model/stable-diffusion-coreml.mlpackage")
sequence = [
    {"depth": 1, "behavior": "Hopeful Initiate"},
    {"depth": 4, "behavior": "Doubt Rising"},
    {"depth": 7, "behavior": "Fall Into Zealotry"}
]
motion.generate_sakuga_sequence(sequence, style="renaissance_darkcore")
```

Next: We'll wire in real frame generation using Ai-tan, and output `.fbc.anim` files.
