"""
durst_vm.py – DURST Interpreter (Pythonista edition)
Executes DURST code embedded in .fbc files or entered manually.
"""

def run_durst_code(code):
    lines = [line.strip() for line in code.strip().split("\n") if line.strip()]
    variables = {}
    pc = 0
    loop_stack = []

    def eval_line(line):
        if line.startswith("OUTPUT"):
            _, msg = line.split(" ", 1)
            print("[DURST OUTPUT] " + msg.strip().strip('"'))
        elif line.startswith("SET"):
            _, var, _, val = line.split()
            variables[var] = int(val)
        elif line.startswith("WHILE"):
            _, var, _, val = line.split()
            return ("WHILE", var, int(val))
        elif line == "END WHILE":
            return "END"
        elif line.startswith("LOOP"):
            return ("LOOP",)
        elif line.startswith("BEGIN") or line.startswith("END"):
            return None
        elif line.startswith("CYCLE = CYCLE - 1"):
            if "CYCLE" in variables:
                variables["CYCLE"] -= 1
        return None

    print("[*] Running DURST Code:")
    while pc < len(lines):
        line = lines[pc]
        result = eval_line(line)

        if isinstance(result, tuple) and result[0] == "WHILE":
            var, val = result[1], result[2]
            if variables.get(var, 0) > val:
                loop_stack.append(pc)
            else:
                # Skip to after END WHILE
                while pc < len(lines) and lines[pc] != "END WHILE":
                    pc += 1
        elif result == "END":
            if loop_stack:
                pc = loop_stack[-1] - 1
        pc += 1

if __name__ == "__main__":
    print("Paste your DURST code below (end with ENTER x2):")
    durst_lines = []
    while True:
        line = input()
        if not line.strip():
            break
        durst_lines.append(line)
    run_durst_code("\n".join(durst_lines))
