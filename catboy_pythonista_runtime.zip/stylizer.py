"""
stylizer.py – Catboy.ai CoreML local frame generator (Pythonista-friendly)
"""

import os
import numpy as np
from PIL import Image
import coremltools as ct

def generate_frame(prompt, model_path="model/stable-diffusion-coreml.mlpackage"):
    print(f"[*] Generating frame for prompt: {prompt}")
    model = ct.models.MLModel(model_path)

    try:
        input_dict = {"prompt": prompt}
        output = model.predict(input_dict)
        img_data = output["image"]
        image = Image.fromarray(np.uint8(img_data))
        output_path = os.path.join("outputs", "generated_frame.png")
        image.save(output_path)
        print(f"[✓] Frame saved to: {output_path}")
    except Exception as e:
        print(f"[!] Generation failed: {e}")

if __name__ == "__main__":
    user_prompt = input("Prompt for stylization: ")
    generate_frame(user_prompt)
