"""
Dio-kun (Pythonista Native) – Catboy.ai Runtime Core
No subprocess, runs pure Python iOS code.
"""

import os
import sys

print("\n[CATBOY.AI] Dio-kun ready to launch your recursive fate.")

os.makedirs("outputs", exist_ok=True)
os.makedirs("assets", exist_ok=True)

def menu():
    print("""
[1] Run Sakuga Stylizer
[2] Firebar Compress
[3] Firebar Decompress
[4] DURST Interpreter
[Q] Quit
    """)
    return input(">> ").strip().lower()

def stylize():
    exec(open("stylizer.py").read(), globals())

def compress():
    exec(open("firebar.py").read(), globals())

def decompress():
    exec(open("firebar.py").read(), globals())  # also handles decode in same script

def durst():
    exec(open("durst_vm.py").read(), globals())

while True:
    choice = menu()
    if choice == "1": stylize()
    elif choice == "2": compress()
    elif choice == "3": decompress()
    elif choice == "4": durst()
    elif choice == "q":
        print("See you in the next loop, master~")
        break
    else:
        print("Meow? Try again.")
