"""
catboy_ui.py
Cute pixel-style PyQt UI for SakugaCore
"""

from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QFileDialog,
    QVBoxLayout, QHBoxLayout, QLineEdit, QProgressBar
)
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt
import sys, os

class CatboyUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Catboy.ai – Sakuga Render UI")
        self.setStyleSheet(open("sakuga_palette.qss").read())
        self.init_ui()

    def init_ui(self):
        self.layout = QVBoxLayout()
        self.setFixedSize(480, 600)

        self.label_emote = QLabel(self)
        self.label_emote.setPixmap(QPixmap("ui_assets/idle.png").scaled(128, 128, Qt.AspectRatioMode.KeepAspectRatio))
        self.label_emote.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.label_emote)

        self.prompt_input = QLineEdit(self)
        self.prompt_input.setPlaceholderText("Enter stylization prompt")
        self.layout.addWidget(self.prompt_input)

        self.file_button = QPushButton("Choose Fight Video")
        self.file_button.clicked.connect(self.choose_file)
        self.layout.addWidget(self.file_button)

        self.render_button = QPushButton("Render Sakuga")
        self.render_button.clicked.connect(self.render_sakuga)
        self.layout.addWidget(self.render_button)

        self.progress = QProgressBar(self)
        self.layout.addWidget(self.progress)

        self.setLayout(self.layout)

    def choose_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "Choose fight video")
        if file:
            self.video_path = file
            self.file_button.setText(f"Selected: {os.path.basename(file)}")

    def render_sakuga(self):
        self.progress.setValue(10)
        self.label_emote.setPixmap(QPixmap("ui_assets/processing.png").scaled(128, 128))
        # Here you'd call the stylizer pipeline
        import time
        for i in range(11, 91, 20):
            QApplication.processEvents()
            self.progress.setValue(i)
            time.sleep(0.2)
        self.progress.setValue(100)
        self.label_emote.setPixmap(QPixmap("ui_assets/complete.png").scaled(128, 128))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = CatboyUI()
    win.show()
    sys.exit(app.exec())
